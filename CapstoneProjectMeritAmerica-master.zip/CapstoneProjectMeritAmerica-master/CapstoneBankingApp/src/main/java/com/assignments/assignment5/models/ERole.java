package com.assignments.assignment5.models;

public enum ERole {
	AccountHolder,
    admin
}
