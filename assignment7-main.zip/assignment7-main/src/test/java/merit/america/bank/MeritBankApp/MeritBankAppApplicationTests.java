package merit.america.bank.MeritBankApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeritBankAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
