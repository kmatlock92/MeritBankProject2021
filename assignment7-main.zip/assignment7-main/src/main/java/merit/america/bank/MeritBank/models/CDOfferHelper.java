package merit.america.bank.MeritBank.models;

public class CDOfferHelper {
	private int id;
	
	CDOfferHelper() {}

	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}
	
}