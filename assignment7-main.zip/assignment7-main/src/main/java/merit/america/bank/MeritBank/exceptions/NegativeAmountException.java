package merit.america.bank.MeritBank.exceptions;

public class NegativeAmountException extends Exception {
	NegativeAmountException() {
		System.out.println("NegativeAmountException");
	}

	private static final long serialVersionUID = 1L;
}

