package merit.america.bank.MeritBank.exceptions;

public class ExceedsCombinedBalanceLimitException extends Exception {
	public ExceedsCombinedBalanceLimitException() {
		System.out.println("ExceedsCombinedBalanceLimitException");
	}

	private static final long serialVersionUID = 1L;
}
