package merit.america.bank.MeritBank.exceptions;

public class ExceedsFraudSuspicionLimitException extends Exception {

	private static final long serialVersionUID = 1L;
}
